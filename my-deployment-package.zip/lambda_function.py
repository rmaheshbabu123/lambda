import json
import sys
import psycopg2

def lambda_handler(event, context):
    # TODO implement
    with open("config.json", "r") as f:
          config = json.load(f)
    
    # Connect to the RDS Aurora PostgreSQL database
    conn = psycopg2.connect(
        host=config["rds"]["host"],
        port=config["rds"]["port"],
        dbname=config["rds"]["dbname"],
        user=config["rds"]["user"],
        password=config["rds"]["password"]
    )
    
        # Create a cursor for executing SQL commands
    cur = conn.cursor()
    
        # Loop through the list of users in the config file
    for user in config["users"]:
        # Construct the SQL command to create a user
        sql = "CREATE USER {} WITH PASSWORD '{}'".format(user["username"], user["password"])

        # Execute the SQL command to create the user
        cur.execute(sql)

        # Grant the SELECT, UPDATE, and INSERT privileges to the user
        cur.execute("GRANT SELECT, UPDATE, INSERT ON ALL TABLES IN SCHEMA public TO {}".format(user["username"]))

    # Commit the changes to the database
    conn.commit()
    
    # Close the cursor and the connection
    cur.close()
    conn.close()

    return {
        'statusCode': 200,
        'body': json.dumps('Users created successfully.!')
    }
